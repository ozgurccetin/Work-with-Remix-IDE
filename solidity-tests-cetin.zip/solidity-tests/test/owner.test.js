const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Owner", function () {
  it("test contract owner", async function () {
    const [acc_0] = await ethers.getSigners();
    const Owner = await ethers.getContractFactory("Owner");
    const owner = await Owner.deploy();
    await owner.deployed();
    expect(await owner.getOwner()).to.equal(acc_0.address);
  });

  it("test change owner", async function () {
    const [_, acc_1] = await ethers.getSigners();
    const Owner = await ethers.getContractFactory("Owner");
    const owner = await Owner.deploy();
    await owner.deployed();
    const tx = await owner.changeOwner(acc_1.address);
    await tx.wait();
    expect(await owner.getOwner()).to.equal(acc_1.address);
  });
});
